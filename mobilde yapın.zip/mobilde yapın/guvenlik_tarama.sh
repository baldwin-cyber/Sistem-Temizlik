#!/data/data/com.termux/files/usr/bin/bash
#
# guvenlik_tarama.sh
# Termux icin Android cihaz + web sitesi guvenlik tarama araci
# Yalnizca KENDI cihazniz ve KENDI web siteniz icin kullanin.
#
# Kurulum:
#   pkg install curl openssl-tool net-tools -y
#   chmod +x guvenlik_tarama.sh
#   ./guvenlik_tarama.sh

KIRMIZI='\033[0;31m'
SARI='\033[1;33m'
YESIL='\033[0;32m'
MAVI='\033[0;36m'
NC='\033[0m'

TARIH=$(date +"%Y-%m-%d_%H-%M-%S")
RAPOR="GuvenlikRaporu_${TARIH}.txt"

RISKLI=0
UYARI=0
OK=0

yaz_rapor() {
    local baslik="$1"
    local durum="$2"
    local detay="$3"
    local oneri="$4"

    case "$durum" in
        RISKLI) renk=$KIRMIZI; RISKLI=$((RISKLI+1));;
        UYARI)  renk=$SARI; UYARI=$((UYARI+1));;
        OK)     renk=$YESIL; OK=$((OK+1));;
        *)      renk=$MAVI;;
    esac

    echo -e "${renk}[$durum]${NC} $baslik"
    [ -n "$detay" ] && echo "    -> $detay"

    {
        echo "[$durum] $baslik"
        [ -n "$detay" ] && echo "    Detay: $detay"
        [ -n "$oneri" ] && echo "    Oneri: $oneri"
        echo ""
    } >> "$RAPOR"
}

echo -e "${MAVI}"
echo "====================================================="
echo "  ANDROID (TERMUX) + WEB SITESI GUVENLIK TARAMASI"
echo "====================================================="
echo -e "${NC}"

echo "Guvenlik Raporu - $TARIH" > "$RAPOR"
echo "=====================================" >> "$RAPOR"

# ---------- 1) Root durumu ----------
if command -v su >/dev/null 2>&1; then
    yaz_rapor "Root Erisimi" "UYARI" "Cihazda su komutu bulundu, cihaz root'lu olabilir." "Root'lu cihazlar guvenlik riskini artirir; gereksizse root kaldirilmali."
else
    yaz_rapor "Root Erisimi" "OK" "Cihaz root'lu gorunmuyor." ""
fi

# ---------- 2) Termux depolama izni ----------
if [ -d "$HOME/storage" ]; then
    yaz_rapor "Depolama Erisimi" "BILGI" "Termux'un cihaz depolamasina erisimi var (termux-setup-storage calistirilmis)." "Gereksizse kaldirin."
else
    yaz_rapor "Depolama Erisimi" "OK" "Termux'un genis depolama erisimi yok." ""
fi

# ---------- 3) Acik/dinleyen portlar (cihazda calisan servisler) ----------
echo -e "\n${MAVI}--- Cihazda Acik Portlar ---${NC}"
if command -v netstat >/dev/null 2>&1; then
    PORTLAR=$(netstat -tulnp 2>/dev/null | grep LISTEN)
    if [ -n "$PORTLAR" ]; then
        echo "$PORTLAR" | while read -r line; do
            echo "  $line"
        done
        yaz_rapor "Dinleyen Portlar" "UYARI" "Cihazda aktif dinleyen servisler var (yukarida listelendi)." "Gereksiz servisleri (ornek: sshd, ftp) kapatin."
    else
        yaz_rapor "Dinleyen Portlar" "OK" "Aktif dinleyen servis bulunamadi." ""
    fi
else
    yaz_rapor "Dinleyen Portlar" "BILGI" "net-tools kurulu degil (pkg install net-tools)." ""
fi

# ---------- 4) Termux SSH servisi acik mi ----------
if pgrep -x "sshd" >/dev/null 2>&1; then
    yaz_rapor "SSH Servisi (Termux)" "UYARI" "SSH sunucusu calisiyor." "Kullanmiyorsaniz 'pkill sshd' ile kapatin, kullaniyorsaniz guclu parola/anahtar dogrulamasi kullanin."
else
    yaz_rapor "SSH Servisi (Termux)" "OK" "SSH servisi calismiyor." ""
fi

# ---------- 5) Yuklu paketlerde bilinen guncel olmayanlar ----------
echo -e "\n${MAVI}--- Termux Paket Guncelligi ---${NC}"
if command -v pkg >/dev/null 2>&1; then
    ESKI=$(pkg list-installed 2>/dev/null | wc -l)
    yaz_rapor "Paket Listesi" "BILGI" "$ESKI paket kurulu. Guncelligi kontrol etmek icin 'pkg update && pkg upgrade' calistirin." ""
fi

# ================= WEB SITESI KONTROLU =================
echo ""
read -p "Taramak istediginiz web sitesi adresi (bos gecebilirsiniz, orn: https://siteniz.com): " SITEURL

if [ -n "$SITEURL" ]; then
    echo -e "\n${MAVI}===== WEB SITESI GUVENLIK KONTROLU: $SITEURL =====${NC}\n"

    if ! command -v curl >/dev/null 2>&1; then
        echo "curl kurulu degil. Kurmak icin: pkg install curl -y"
    else
        # HTTPS kontrolu
        if [[ "$SITEURL" != https://* ]]; then
            yaz_rapor "HTTPS" "RISKLI" "Site HTTPS kullanmiyor." "SSL sertifikasi kurup HTTPS zorunlu hale getirin."
        else
            yaz_rapor "HTTPS" "OK" "Site HTTPS uzerinden calisiyor." ""
        fi

        HEADERS=$(curl -sI --max-time 15 "$SITEURL")

        if [ -z "$HEADERS" ]; then
            yaz_rapor "Web Sitesi Erisimi" "RISKLI" "Siteye erisilemedi." "URL'yi ve sunucu erisimini kontrol edin."
        else
            declare -A HEADER_ONERI=(
                ["Strict-Transport-Security"]="HSTS eksik. Downgrade saldirilarina karsi ekleyin."
                ["X-Content-Type-Options"]="X-Content-Type-Options eksik. 'nosniff' ekleyin."
                ["X-Frame-Options"]="X-Frame-Options eksik. Clickjacking riskine karsi ekleyin."
                ["Content-Security-Policy"]="CSP eksik. XSS riskine karsi ekleyin."
            )
            for h in "${!HEADER_ONERI[@]}"; do
                if echo "$HEADERS" | grep -qi "^$h:"; then
                    yaz_rapor "HTTP Header: $h" "OK" "Mevcut." ""
                else
                    yaz_rapor "HTTP Header: $h" "UYARI" "Eksik." "${HEADER_ONERI[$h]}"
                fi
            done

            SERVER_HDR=$(echo "$HEADERS" | grep -i "^Server:" | tr -d '\r')
            if [ -n "$SERVER_HDR" ]; then
                yaz_rapor "Server Header" "UYARI" "Sunucu bilgisi ifsa ediliyor: $SERVER_HDR" "Sunucu/versiyon bilgisini gizleyin."
            fi

            POWERED_HDR=$(echo "$HEADERS" | grep -i "^X-Powered-By:" | tr -d '\r')
            if [ -n "$POWERED_HDR" ]; then
                yaz_rapor "X-Powered-By Header" "UYARI" "Teknoloji bilgisi ifsa ediliyor: $POWERED_HDR" "Bu header kaldirilmali."
            fi
        fi

        # SSL sertifika bitis tarihi
        if [[ "$SITEURL" == https://* ]] && command -v openssl >/dev/null 2>&1; then
            HOST=$(echo "$SITEURL" | sed -E 's#https://##' | cut -d/ -f1)
            BITIS=$(echo | openssl s_client -servername "$HOST" -connect "$HOST:443" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)
            if [ -n "$BITIS" ]; then
                BITIS_EPOCH=$(date -d "$BITIS" +%s 2>/dev/null)
                SIMDI_EPOCH=$(date +%s)
                if [ -n "$BITIS_EPOCH" ]; then
                    KALAN_GUN=$(( (BITIS_EPOCH - SIMDI_EPOCH) / 86400 ))
                    if [ "$KALAN_GUN" -lt 15 ]; then
                        yaz_rapor "SSL Sertifikasi" "RISKLI" "$KALAN_GUN gun icinde sona eriyor ($BITIS)." "Sertifika yenilenmeli."
                    else
                        yaz_rapor "SSL Sertifikasi" "OK" "Gecerlilik suresi: $KALAN_GUN gun ($BITIS)." ""
                    fi
                fi
            else
                yaz_rapor "SSL Sertifikasi" "BILGI" "Sertifika bilgisi alinamadi." ""
            fi
        fi
    fi
fi

# ---------- Ozet ----------
echo -e "\n${MAVI}===== TARAMA TAMAMLANDI =====${NC}"
echo -e "${KIRMIZI}Riskli: $RISKLI${NC}   ${SARI}Uyari: $UYARI${NC}   ${YESIL}OK: $OK${NC}"
echo "Detayli rapor kaydedildi: $RAPOR"

{
    echo "====================================="
    echo "OZET: Riskli=$RISKLI  Uyari=$UYARI  OK=$OK"
} >> "$RAPOR"
